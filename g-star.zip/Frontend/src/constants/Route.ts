export const ROUTES = [
  {
    name: "All",
    url: "products",
  },
  {
    name: "Hoodie",
    url: "hoodie",
  },
  {
    name: "T-shirt",
    url: "t-shirt",
  },
  {
    name: "Cap",
    url: "cap",
  },
  {
    name: "Hat",
    url: "hat",
  },
  {
    name: "Sticker",
    url: "sticker",
  },
  
  // {
  //   name: "Men",
  //   url: "men's clothing",
  // },
  // {
  //   name: "Women",
  //   url: "women's clothing",
  // },
  // {
  //   name: "Electronics",
  //   url: "electronics",
  // },
  // {
  //   name: "Jewelery",
  //   url: "jewelery",
  // },
];
